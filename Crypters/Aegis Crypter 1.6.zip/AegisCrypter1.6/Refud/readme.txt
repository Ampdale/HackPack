If can't FUD, try to use VMProtect to Refud.
There may be some effect.