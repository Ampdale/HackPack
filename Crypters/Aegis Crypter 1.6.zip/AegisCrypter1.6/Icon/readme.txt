
Icon download:

http://aegiscrypter.googlecode.com/files/Icon.zip